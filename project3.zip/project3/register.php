<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sign Up</title>
	<link rel="stylesheet" href="styles.css">
</head>

<body onload ="checkMode()">
	<div class="wrapper">
		<div class="header">
			<div class="logo">
				<h1>Premier Tutors</h1>
				<img src="logo.png" alt="LOGO" />
			</div>
		</div> 
		<div class="navbar">
			<a href="./index.html">Home</a>
			<a href="http://localhost/register.php">Register</a>
			<a href="http://localhost/login.php">Login</a>
			<a href="http://tutorlogin.php">Tutor Login</a>
			<a href="./about.html">About</a>
			<a href="./contact.html">Contact Us</a>
			<a href="./tutors.html">Meet Our Tutors</a>
			<button class="button" onclick="darkMode()">Dark Mode</button>
		</div>
	
		<div class="main">
			<div class="column1"></div>
			<div class="column2">
				<div class="cc">
					<div class="f1"></div>
					<div class="formcont">
						<h1>Registration</h1>
						<p>Please fill in this form to register as a student.</p>
						<?php
						if (isset($_POST["submit"])) {
							$studentname = $_POST["studentname"];
							$email = $_POST["email"];
							$password = $_POST["psw"];
							$passwordRepeat = $_POST["psw-repeat"];
							$errors = array();

							if (empty($studentname) || empty($email) || empty($password) || empty($passwordRepeat)) {
								array_push($errors, "All fields are required.");
							}

							if ($password !== $passwordRepeat) {
								array_push($errors, "Passwords do not match.");
							}

						
							require_once "database.php"; 
						
							$sql = "SELECT * FROM student WHERE email = '$email'";
							$result = mysqli_query($conn, $sql);
							$rowCount = mysqli_num_rows($result);
							if ($rowCount > 0) {
								array_push($errors, "Email already exists.");
							}

							if (count($errors) > 0) {
								foreach ($errors as $error) {
									echo "<div class='alert alert-danger'>$error</div>";
								}
							} else {
							
								$passwordHash = password_hash($password, PASSWORD_DEFAULT);

								
								$sql = "INSERT INTO student (studentName, email, Password) VALUES (?, ?, ?)";
								$stmt = mysqli_stmt_init($conn);
								if (mysqli_stmt_prepare($stmt, $sql)) {
									mysqli_stmt_bind_param($stmt, "sss", $studentname, $email, $passwordHash);
									mysqli_stmt_execute($stmt);
									echo "<div class='alert alert-success'>You are registered successfully.</div>";
								} else {
									die("Something went wrong");
								}
							}
						}
						?>
						<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
							<label for="studentname"><b>Student Name</b></label>
							<input type="text" placeholder="Enter Student Name" name="studentname" required>
							<br><br>
							<label for="email"><b>Email</b></label>
							<input type="text" placeholder="Enter Email" name="email" required>
							<br><br>
							<label for="psw"><b>Password</b></label>
							<input type="password" placeholder="Enter Password" name="psw" required>
							<br><br>
							<label for="psw-repeat"><b>Repeat Password</b></label>
							<input type="password" placeholder="Repeat Password" name="psw-repeat" required>
							<br><br>
							<label>
								<input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
							</label>
							<br><br>
							<button type="button" class="cancelbtn">Cancel</button>
							<button type="submit" name="submit" class="signupbtn">Sign Up</button>
						</form>
					</div>
					<div class="f2"></div>
				</div>
			</div>
			<div class="column3"></div>
		</div>
	
		<div class="footer">
			<div class="fcont">
				<h2>Premier Tutors</h2>
				<a href="#">premiertutors@gmail.com</a>
				<br /><br /><br /><br />
				<a href="#wrapper"> Back to Top </a>
				<br /><br />
				Copyright &copy; 2024 By Premier Tutors
			</div>
		</div>
	
	</div>
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="scripts.js" type="text/javascript"></script>

</html>
