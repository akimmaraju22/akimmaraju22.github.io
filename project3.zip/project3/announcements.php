<?php
session_start();


if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: login.php"); // 
    exit;
}


$sql = "SELECT * FROM announcements";
$result = mysqli_query($conn, $sql);


if ($result->num_rows > 0) {
    
    while ($row = $result->fetch_assoc()) {
        echo "<div>";
        echo "<h2>{$row['title']}</h2>";
        echo "<p>{$row['description']}</p>";
        echo "</div>";
    }
} else {
    echo "<p>No announcements found.</p>";
}
?>
