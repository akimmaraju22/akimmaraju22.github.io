function checkMode(){

    $(document).ready(function() {

        if(localStorage.getItem('isDarkMode') === 'true') {
    
            setDarkMode();
    
        } 
        
        else {
    
            setLightMode();
    
        }
    
    });

}


function darkMode() {
    
    var isDark = localStorage.getItem('isDarkMode') === 'true';

    if (!isDark) {
    
        setDarkMode();
        localStorage.setItem('isDarkMode', 'true');
        
    } 
    
    else {

        setLightMode();
        localStorage.setItem('isDarkMode', 'false');

    }
    
}

function setDarkMode() {

    $(".navbar").css('background-color', 'black');
    $(".navbar a").css('color', 'gray');
    $(".column1, .column2, .column3").css('background-color', '#222222');
    $(".column2 p, .logo h1").css('color', 'white');
    $(".column2 h1").css('color', 'gray');
    $(".header, .footer").css('background-color', '#484848');

}

function setLightMode() {

    $(".navbar").css('background-color', '#9A9E85');
    $(".navbar a").css('color', 'black');
    $(".column1, .column2, .column3").css('background-color', '#3A6960');
    $(".column2 p").css('color', '#000c33');
    $(".column2 h1, .logo h1").css('color', 'black');
    $(".header, .footer").css('background-color', '#97C8B4');

}


