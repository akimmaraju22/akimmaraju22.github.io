<?php
session_start();


if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: login.php"); 
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    
    
    $title = $_POST['title'];
    $description = $_POST['description'];


 
    header("Location: announcements.php"); /
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Create Announcment</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<form action="create_announcement.php" method="post">
    <label for="title">Title:</label><br>
    <input type="text" id="title" name="title" required><br>
    <label for="description">Description:</label><br>
    <textarea id="description" name="description" required></textarea><br>
    <input type="submit" value="Create Announcement">
</form>
</body>
</html>
