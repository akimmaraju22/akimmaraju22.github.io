<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>dashboard</title>

</head>

<body onload ="checkMode()">
	<div class="wrapper">
	<div class="header">
		<div class="logo">
		<h1>STUDENT DASHBOARD</h1>
	
	</div>
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="scripts.js" type="text/javascript"></script>

</html>
