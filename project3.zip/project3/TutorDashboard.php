<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Home</title>
	<link rel="stylesheet" href="styles.css">
</head>



<body onload ="checkMode()">
	
	<div class="wrapper">
	<div class="header">
		<div class="logo">
		<h1>Tutor Dashboard</h1>
		<img src="logo.png" alt="LOGO" />
		</div>
	</div> 
  	<div class="navbar">
  		<a href="./index.html">Home</a>

		<button class="button" onclick="darkMode()">Dark Mode</button>
	</div>
	
	<div class="main">
		<div class="column1"></div>
		<div class="column2">
		<h1>Welcome to your dashboard</h1>
	
		<br><br>
		<br><br>
		<br><br>
		<br><br>
		<br><br>
		<br><br>
		</div>
		<div class="column3"></div>
	</div>
	
	<div class="footer">
		<div class="fcont">
        <h2>Premier Tutors</h2>

     
        <br />
        <br />
        <br>
        <br>

        <a href="#wrapper"> Back to Top </a>
        <br />
		<br />
		Copyright &copy; 2024 By Premier Tutors
		</div>
	</div>
	
	</div>
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="scripts.js" type="text/javascript"></script>

</html>