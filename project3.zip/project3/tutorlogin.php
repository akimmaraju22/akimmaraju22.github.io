<?php
session_start(); 

if(isset($_SESSION["user"]) && $_SESSION["user"] === "yes") {
    header("Location: localhost/TutorDashboard.php");
    exit();
}

if (isset($_POST["login"])) {
	$email = $_POST["email"] ?? "";
    $password = $_POST["psw"];
    require_once "database.php";
    $sql = "SELECT * FROM tutors WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
    if ($user) {
        $passwordFromDatabase = $user["password"]; 
        if ($password === $passwordFromDatabase) {
            $_SESSION["user"] = "yes";
            header("Location: TutorDashboard.php");
            exit(); 
        } else {
            echo "<div class='alert alert-danger'>Password does not match</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Email does not match</div>";
    }
    
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body onload ="checkMode()">
<div class="wrapper">
    <div class="header">
        <div class="logo">
            <h1>Premier Tutors</h1>
            <img src="logo.png" alt="LOGO" />
        </div>
    </div>
    <div class="navbar">
        <a href="./index.html">Home</a>
        <a href="./register.php">Register</a>
        <a href="./login.html">Login</a>
		<a href="./tutorlogin.php">Tutor Login</a>
        <a href="./about.html">About</a>
        <a href="./contact.html">Contact Us</a>
        <a href="./tutors.html">Meet Our Tutors</a>
        <button class="button" onclick="darkMode()">Dark Mode</button>
    </div>

    <div class="main">
        <div class="column1"></div>
        <div class="column2">
            <div class="cc">
                <div class="f1"></div>
                <div class="formcont">
                    <h1>Tutor Login</h1>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <label for="uname"><b>Tutor Name</b></label>
                        <input type="text" placeholder="Enter Tutor Name" name="tname" required>
                        <br><br>
						<label for ="email"><b>email</b></label>
						<input type="text" placeholder="enter email" name="email" required>
						<br><br>
                        <label for="psw"><b>Password</b></label>
                        <input type="password" placeholder="Enter Password" name="psw" required>
                        <br><br>
                        <button type="submit" name="login">Login</button>
                        <label>
                            <input type="checkbox" checked="checked" name="remember"> Remember me
                        </label>
                        <br><br>
                        <button type="button" class="cancelbtn">Cancel</button>
                        <br><br>
                        <span class="psw">Forgot <a href="./forgotpassword.html">password?</a></span>
                        <br><br>
                        <br><br>
                        <br><br>
                    </form>

                </div>
                <div class="f2"></div>
            </div>
        </div>
        <div class="column3"></div>
    </div>

    <div class="footer">
        <div class="fcont">
            <h2>Premier Tutors</h2>

            <a href="#">premiertutors@gmail.com</a>
            <br />
            <br />
            <br>
            <br>

            <a href="#wrapper"> Back to Top </a>
            <br />
            <br />
            Copyright &copy; 2024 By Premier Tutors
        </div>
    </div>

</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="scripts.js" type="text/javascript"></script>

</html>

