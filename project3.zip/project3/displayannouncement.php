<?php
session_start();

$sql = "SELECT * FROM announcements";
$result = mysqli_query($conn, $sql);

while ($row = $result->fetch_assoc()) {
    echo "<h2>{$row['title']}</h2>";
    echo "<p>{$row['description']}</p>";
    
}
?>
