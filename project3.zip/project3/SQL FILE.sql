CREATE DATABASE premiertutors;
USE premiertutors;

CREATE TABLE Student( studentId int PRIMARY KEY, 
studentName varchar(30) NOT NULL, 
Password VARCHAR (50) NOT NULL,
GPA double,
phoneNumber varchar(50) NOT NULL,
Email VARCHAR(50) NOT NULL);

INSERT INTO Student (studentId, studentName, Password, GPA, phoneNumber, Email) VALUES
(1001, 'Jenna', 'jenn123', 3.5, 6234567890, 'jenna@gmail.com'),
(1002, 'Alex Johnson', 'alex123', 3.8, 6876543210, 'alex@gmail.com'),
(1003, 'Michael Bobenko', 'michael234', 3.2, 6345678901, 'michael@gmail.com'),
(1004, 'Samreet Dhaliwal', 'Samreet345', 3.9, 7456789012, 'sam@gmail.com'),
(1005, 'Daniel Williams', 'daniel987', 2.9, 7567890123, 'daniel@gmail.com'),
(1006, 'Sarah Ortega', 'sarah876', 3.13, 7678901234, 'sarah@gmail.com'),
(1007, 'Jasleen kaur', 'jas123', 3.7, 7789012345, 'jasleen@gmail.com'),
(1008, 'Amrinder Sandhu', 'Amrinder123', 3.4, 7890123456, 'Amrinder@gmail.com'),
(1009, 'Andy Smith', 'Andy123', 3.1, 7901234567, 'andy@gmail.com'),
(1010, 'Olivia Jackson', 'olivia123', 3.19, 6012345678, 'olivia@gmail.com'),
(1011, 'Ethan White', 'ethan123', 3.8, 6234567890, 'ethan@gmail.com'),
(1012, 'Manpreet Singh', 'Manpreet123', 3.0, 7345678901, 'manpreet@gmail.com'),
(1013, 'Noah', 'noah123', 3.9, 6456789012, 'noah@gmail.com'),
(1014, 'Sophia Gill', 'sophia123', 3.6, 7567890123, 'sophia@gmail.com'),
(1015, 'Tony Montana', 'Tony123', 3.3, 6678901234, 'tony@gmail.com'),
(1016, 'Britney', 'Britney123', 3.7, 6789012345, 'britney@gmail.com'),
(1017, 'Jessie', 'jessie123', 3.4, 7890123456, 'jessie@gmail.com'),
(1018, 'Millie Brown', 'millie123', 3.1, 7901234567, 'millie@gmail.com'),
(1019, 'Ava Johnson', 'ava123', 3.5, 6234567890, 'ava@gmail.com'),
(1020, 'Ryan Anderson', 'ryan123', 3.8, 6876543210, 'ryan@gmail.com'),
(1021, 'Isabella Martinez', 'isabella123', 3.2, 6345678901, 'isabella@gmail.com'),
(1022, 'Mason Wilson', 'mason123', 3.9, 7456789012, 'mason@gmail.com'),
(1023, 'Sophie Lewis', 'sophie123', 2.9, 7567890123, 'sophie@gmail.com');


CREATE TABLE Tutor (
    TutorID INT  PRIMARY KEY,
    TutorName VARCHAR(100) NOT NULL,
    Coursename VARCHAR(255) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Password VARCHAR (100) NOT NULL);
  
  INSERT INTO Tutor (TutorID, TutorName, coursename , Email, Password) VALUES
(101, 'Rehman Mann', '20th Century World History, Geography of Canada, Intro To Walking', 'RehmanMann@gmail.com', 'Mann123'),
(102, 'Ryan Nelson', 'Geography of Canada, 20th Century World History', 'Ryannelson@gmail.com', 'Ryan123'),
(103, 'Akshay Immaraju', 'Statistics, System Analysis and Design, Operating Systems', 'akshay@gmail.com', 'akshay123'),
(104, 'Navreet Kaur', 'System Analysis and Design, Statistics', 'Navreetk@gmail.com', 'Navreet123'),
(105, 'Aviel San Agustin', 'Intro To Walking, Music, Geography of Canada', 'aviel@gmail.com', 'Aviel456'),
(106, 'Jun', 'Operating Systems, Statistics', 'jun@gmail.com', 'pass789');


CREATE TABLE Course (
    CourseID INT PRIMARY KEY,
    CourseName VARCHAR(100) NOT NULL,
    Description TEXT,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL);

INSERT INTO Course (CourseID, CourseName, Description, StartDate, EndDate)
VALUES
    (3001, '20th Century World History', 'Study of major events and developments in world history during the 20th century', '2024-01-05', '2024-03-30'),
    (3002, 'Geography of Canada', 'Exploration of the physical and cultural geography of Canada', '2024-01-06', '2024-03-30'),
    (3003, 'Statistics', 'Introduction to statistical concepts and methods for data analysis', '2024-01-09', '2024-04-10'),
    (3004, 'System Analysis and Design', 'Study of techniques and methodologies for analyzing and designing information systems', '2024-01-09', '2024-04-05'),
    (3005, 'Intro to Walking', 'Introduction to the benefits and techniques of walking for fitness and wellness', '2024-01-10', '2024-04-05'),
    (3006, 'Operating Systems', 'Study of fundamental principles, functionalities, and design aspects of computer operating systems', '2024-01-10', '2024-04-04');
    
    
CREATE TABLE Enrollment (
    EnrollmentID INT PRIMARY KEY,     
    StudentID INT,
    CourseID INT,
    EnrollmentDate DATE NOT NULL,
    Grade VARCHAR(50),
    FOREIGN KEY (StudentID) REFERENCES Student(StudentID),
    FOREIGN KEY (CourseID) REFERENCES Course(CourseID));
    
    INSERT INTO Enrollment (EnrollmentID, StudentID, CourseID, EnrollmentDate, Grade)
VALUES
    (901, 1001, 3001, '2024-01-05', 'Not Graded Yet'),
    (902, 1002, 3002, '2024-01-20', 'Not Graded Yet'),
    (903, 1006, 3003, '2024-01-10', 'Not Graded Yet'),
    (904, 1005, 3004, '2024-01-25', 'Not Graded Yet'),
    (905, 1012, 3005, '2024-02-05', 'Not Graded Yet'),
    (906, 1013, 3006, '2024-01-15', 'Not Graded Yet'),
    (907, 1011, 3002, '2024-02-05', 'Not Graded Yet'),
    (908, 1003, 3003, '2024-01-20', 'Not Graded Yet'),
    (909, 1004, 3006, '2024-02-07', 'Not Graded Yet'),
    (910, 1007, 3002, '2024-01-22', 'Not Graded Yet'),
    (911, 1008, 3003, '2024-01-12', 'Not Graded Yet'),
    (912, 1012, 3004, '2024-01-10', 'Not Graded Yet'),
    (913, 1013, 3005, '2024-02-03', 'Not Graded Yet'),
    (914, 1009, 3006, '2024-02-02', 'Not Graded Yet'),
    (915, 1023, 3005, '2024-02-05', 'Not Graded Yet'),
    (916, 1003, 3003, '2024-02-03', 'Not Graded Yet'),
    (917, 1008, 3001, '2024-02-09', 'Not Graded Yet'),
    (918, 1008, 3002, '2024-01-24', 'Not Graded Yet'),
    (919, 1004, 3003, '2024-03-02', 'Not Graded Yet'),
    (920, 1018, 3002, '2024-02-06', 'Not Graded Yet'),
    (921, 1017, 3005, '2024-03-01', 'Not Graded Yet'),
    (922, 1010, 3006, '2024-01-01', 'Not Graded Yet'),
    (923, 1011, 3004, '2024-01-10', 'Not Graded Yet'),
    (924, 1021, 3004, '2024-03-05', 'Not Graded Yet'),
    (925, 1014, 3001, '2024-02-11', 'Not Graded Yet'),
    (926, 1017, 3002, '2024-01-28', 'Not Graded Yet'),
    (927, 1020, 3003, '2024-02-18', 'Not Graded Yet'),
    (928, 1014, 3004, '2024-03-05', 'Not Graded Yet'),
    (929, 1015, 3002, '2024-01-06', 'Not Graded Yet'),
    (930, 1010, 3001, '2024-02-06', 'Not Graded Yet'),
    (931, 1016, 3004, '2024-01-15', 'Not Graded Yet'),
    (932, 1019, 3002, '2024-02-10', 'Not Graded Yet'),
    (933, 1014, 3004, '2024-01-13', 'Not Graded Yet'),
    (934, 1012, 3004, '2024-01-05', 'Not Graded Yet'),
    (935, 1018, 3003, '2024-02-06', 'Not Graded Yet'),
    (936, 1023, 3004, '2024-01-10', 'Not Graded Yet'),
    (937, 1015, 3005, '2024-02-06', 'Not Graded Yet'),
    (938, 1022, 3006, '2024-02-10', 'Not Graded Yet'),
    (939, 1016, 3003, '2024-02-05', 'Not Graded Yet');    
    
    
    
    CREATE TABLE TeachAssignment (
    TutorID INT,
    CourseID INT,
    PRIMARY KEY (TutorID, CourseID),
    FOREIGN KEY (TutorID) REFERENCES Tutor(TutorID),
    FOREIGN KEY (CourseID) REFERENCES Course(CourseID));

INSERT INTO TeachAssignment (TutorID, CourseID)
VALUES 
(101, 3001),
(101, 3002),
(101, 3005),
(102, 3002),
(102, 3001),
(103, 3003),
(103, 3004),
(103, 3006),
(104, 3004),
(104, 3003),
(105, 3005),
(105, 3002),
(106, 3006),
(106, 3003);


CREATE TABLE Admin (
    AdminID INT PRIMARY KEY,
    Username VARCHAR(50) NOT NULL,
    Password VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL);
    
    INSERT INTO Admin ( AdminID, Username, Password, Email) values
    (987610, 'Jeff', 'JeFfsMiTh@98-87', 'Jeffsmith46@gmail.com');
    
    CREATE TABLE Video (
    VideoID varchar(50) PRIMARY KEY,
    CourseID INT,
    Title VARCHAR(100) NOT NULL,
    Description TEXT,
    FOREIGN KEY (CourseID) REFERENCES Course(CourseID)
);

INSERT INTO Video (VideoID, CourseID, Title, Description)
VALUES 
('video01', 3001, 'Introduction to Course 3001', 'Overview of the course content for Course "20th Century World History" '),
('video02', 3002, 'Introduction to Course 3002', 'Overview of the course content for Course "Geography of Canada" '),
('video03', 3003, 'Introduction to Course 3003', 'Overview of the course content for Course "Statistics" '),
('video04', 3004, 'Introduction to Course 3004', 'Overview of the course content for Course "System Analysis and Design" '),
('video05', 3005, 'Introduction to Course 3005', 'Overview of the course content for Course "Intro To Walking" '),
('video06', 3006, 'Introduction to Course 3006', 'Overview of the course content for Course "Operating Systems" ');



